﻿#####################################################################
#                                                                   #
# ALL RIGHTS RESERVED, COPYRIGHT (C) Ivanti, 2020                   #
#                                                                   #
# DISCLAIMERS / LIMITATIONS                                         #
# By utilizing this product, you acknowledge that Ivanti            #
# has provided this item on a "as is, where                         #
# is"  basis., without warranty of any kind, express or implied,    #
# including implied warranties of non-infringement, merchantability #
# and fitness for a particular purpose.  Ivanti does not warrant    #
# that the product will meet your requirements, operate in          #
# combination with other software, or be uninterrupted or error     #
# free.  In no event shall Ivanti be liable for any lost revenue,   #
# profit, or data, or for direct, special, indirect, consequential, #
# incidental, or punitive damages however caused and regardless of  #
# the theory of liability, arising out of the use of or inability   #
# to use the product even if Ivanti has been advised of the         #
# possibility of such damages.                                      #
#####################################################################

<#
.SYNOPSIS

Download data files and patches for ISeC and Patch.

In order to use the PowerShell script, the Internet-connected machine must contain the following:
    - Windows PowerShell 4.0 or later
    - Microsoft .NET Framework 4.7.2.461808 or later
    - Windows Management Framework 5.1
    
There are 2 ways to get the pre-reqs:

    1) The best way to get the pre-reqs installed is to run the application pre-req installer and cancel the install once the pre-reqs are done.
    2) Manually download the minimum requirements:
        a. Example, I only have the Windows 7 Windows Management Framework 5.1
            Download URL: https://download.microsoft.com/download/6/F/5/6F5FF66C-6775-42B0-86C4-47D41F2DA187/Win7AndW2K8R2-KB3191566-x64.zip
            Extract and run: Win7AndW2K8R2-KB3191566-x64.msu

.DESCRIPTION

Use this PowerShell script to download data files and patch files for ISeC and Patch. The files can then be copied to and used on a disconnected console. The patch file download capability is only available in ISeC 9.4 or later and Patch 2.4 or later. If you are downloading patches, you can specify which patches to download by referencing either a CSV file that you create using the ISeC console or an XML file that you create using Patch. See the downloadPackageInputFilePath parameter for details on creating the CSV or XML file.

After using the script to download the files, they must be copied to the proper locations on the disconnected console.

ISeC:
    The default location of the DataFile folder is:

        C:\ProgramData\Ivanti\Security Controls\Console\DataFiles

    The default location of the patches folder is:

        C:\ProgramData\Ivanti\Security Controls\Console\Patches

Patch:
    The default location for the catalog files is:

        C:\Users\<%Username%>\Ivanti\Patch

    The patch location is defined on the Settings > Offline Options > Local Source tab.

OEM:
    Customer determines their own default location.

.PARAMETER outDir
    Specifies where to save the data and/or patch files. The script will create two subfolders:
    
    - \DataFiles: This folder will contain the downloaded data files (for ISeC/OEM users) or the downloaded catalog files (for Patch users). 
    
    - \Patches or \Updates: The \Patches folder will be created if you are using ISeC, and the \Updates folder will be created if you are using Patch.  The folder will contain the patches specified by the downloadPackageInputFilePath parameter.
    
    If you do not supply the output directory, the download will not occur.


.PARAMETER product
    Specify what product data you want to download.

    ISeC - Isec
    Patch - Patch
    OEM - OEM

.PARAMETER doNOTDwnlDataFile
    Specify if you want to download data files. Supply if you do NOT want to download data files; omit if you do. The $dwnlAllDataFile parameter is ignored, if $doNOTDwnlDataFile is specified.

.PARAMETER dwnlAllDataFile
    Specify if you want to download ALL data files. This will replace all existing data files. Supply if you want to replace all data files; omit if you only want the lastest. The $dwnlAllDataFile parameter is ignored, if $doNOTDwnlDataFile is specified.

.PARAMETER version
    Specify the product version that you are using. The value is represented by two numeric digits.
    If you do not supply the version number, the download will not occur.
    
    This parameter is required if $doNOTDwnlDataFile is not specified/
    
    Example:
    
    ISeC:
        Version  Supply
        9.5.####.0   9.5
        9.4.####.0   9.4

    Patch:
        Version  Supply
        2.4.####.0   24

    OEM:
        Version  Supply
        9.3.####.0   93
        9.2.####.0   925
        
.PARAMETER downloadPackageInputFilePath
    Applies only to ISeC 9.4 or later and Patch 2.4 or later. There is NO OEM support.

    Specify where the patch file is located. If this parameter is not supplied, patches will not be downloaded.

    The patch file indicates which patches should be downloaded. If you are using ISeC the patch file will be a CSV file. If you are using Patch, the patch file will be an XML data file.

    ISeC:
        To create the CSV file: 
            1) On the disconnected console, go to either to Machine View or Scan View.
            2) Select the patches you want to download
            3) Right-click and select Export download package. 
            4) Save the file and copy it to the connected machine.
    
    Patch:
        To create the XML file: 
            1) Make sure the console is in offline mode (Settings > Offline Options).
            2) Make sure you have the latest catalog files.
            3) From the Patch workspace, select the updates that you want to download.
            4) Click Download (the Offline Download dialog appears).
            5) Click Create file.
                An XML data file is created in your temp folder (C:\Users\<username>\AppData\Local\Temp\).
            6) Save the file and copy it to the connected machine.

    OEM:
        NOT supproted

.PARAMETER replacePatchFile
    Applies only to ISeC 9.4 or later and Patch 2.4 or later.

    Possible values: $true or $false.
    
    This applies only to patch downloads. If you want to replace the existing patch files with the new downloaded files, set this value to $true. If you do not want to overwrite existing files with new patch files, specify $false or use the default.
    
.PARAMETER numThreads 
    Applies only to ISeC 9.4 or later and Patch 2.4 or later.

    Possible values: 1 through 6
    
    This only applies to patch downloads. If the connected machine cannot handle six concurrent downloads, you can decrease the number of threads.

.PARAMETER company
    Applies only to OEM and Patch 2.4 or later and downloading datafiles. The company name is case sensetive. It must match the web sites casing.
    
    This applies to 3rd party companies that want to get their version of the Patch manifest.
    
    This parameter is required for OEM products.
    
    If the web site has MyComPanyName in the URL, you must supply MyComPanyName. Everthing else will fail with a 403 forbidden.
    
.PARAMETER overwriteManifestDownloadURL
    Applies only to downloading datafiles
    
    You can use this to overwrite the manifest download URL CAB path. The default path is http://content.ivanti.com/data/$product/v$versionMajor/${version}${company}/manifest/$script:manifestFileNameCab

.EXAMPLE

    Download just data files

    ISeC: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Isec" -version 9.4

    Patch: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Patch" -version 24

    OEM: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "OEM" -version 93 -company "genericCompany"


.EXAMPLE

    Replace all data files

    ISeC: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Isec" -version 9.4 -dwnlAllDataFile

    Patch: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Patch" -version 24 -dwnlAllDataFile

    OEM: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "OEM" -version 93 -company "genericCompany" -dwnlAllDataFile


.EXAMPLE

    Download just patches

    ISeC: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Isec" -version 9.5 -doNOTDwnlDataFile -downloadPackageInputFilePath "C:\Users\Username\Desktop\Disconnected\ForeignOS.csv"

    Patch: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Patch" -doNOTDwnlDataFile -version 24 -downloadPackageInputFilePath "C:\Users\Username\Desktop\Disconnected\5c7c5279-169f-49cc-b4d5-b87025b749fd.xml"

    OEM: NOT Supported


.EXAMPLE

    Download data files and patches
    
    ISeC: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Isec" -version 9.4 -downloadPackageInputFilePath "C:\Users\Username\Desktop\Disconnected\ForeignOS.csv"
    
    Patch: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Patch" -version 24 -downloadPackageInputFilePath "C:\Users\Username\Desktop\Disconnected\5c7c5279-169f-49cc-b4d5-b87025b749fd.xml"

    OEM: NOT Supported

.EXAMPLE

    Download data files, do not replace patch files if they already exist, and only download a single patch at a time.

    ISeC: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Isec" -version 9.4 -downloadPackageInputFilePath "C:\Users\Username\Desktop\Disconnected\ForeignOS.csv" -replacePatchFile $false -numThreads 1

    Patch: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Patch" -version 24 -downloadPackageInputFilePath "C:\Users\Username\Desktop\Disconnected\5c7c5279-169f-49cc-b4d5-b87025b749fd.xml" -replacePatchFile $false -numThreads 1

    OEM: NOT Supported


.EXAMPLE

    Download data files and patches, replacing existing patch files with the new downloaded files.

    ISeC: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Isec" -version 9.4 -downloadPackageInputFilePath "C:\Users\Username\Desktop\Disconnected\ForeignOS.csv" -replacePatchFile $true

    Patch: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Patch" -version 24 -downloadPackageInputFilePath "C:\Users\Username\Desktop\Disconnected\5c7c5279-169f-49cc-b4d5-b87025b749fd.xml" -replacePatchFile $true

    OEM: NOT Supported

.EXAMPLE

    Download just data files using a specific company's name

    ISeC: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Isec" -version 9.4 -company "genericCompany"

    Patch: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Patch" -version 24 -company "genericCompany"

    OEM: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "OEM" -version 93 -company "genericCompany"

.EXAMPLE

    Download just data files while overwriting the manifest cab URL

    ISeC: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Isec" -version 9.4 -overwriteManifestDownloadURL "http://Diff.Location.com/data/Protect/manifest/engines.manifest.cab"

    Patch: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "Patch" -version 24 -overwriteManifestDownloadURL "http://Diff.Location.com/data/Patch/manifest/engines.manifest.cab"

    OEM: .\DownloadDisconnectedData.ps1 -outdir "C:\Users\Username\Desktop\Disconnected" -product "OEM" -version 93 -company "genericCompany" -overwriteManifestDownloadURL "http://Diff.Location.com/data/Patch/manifest/engines.manifest.cab"

#>

param
(
    [parameter(Mandatory = $true)]
    [string] $outDir = $(throw "Must supply an output directory."),
    [parameter(Mandatory = $true)]
    [string] $product = $(throw "Must supply a product. (Isec, Patch or OEM)"),
    [switch] $doNOTDwnlDataFile,
    [switch] $dwnlAllDataFile,
    [string] $version,
    [string] $downloadPackageInputFilePath,
    [Boolean] $replacePatchFile = $false,
    [int] $numThreads = 6,
    [string] $company,
    [string] $overwriteManifestDownloadURL
)

$SILENT_FLAG = 4
$NOCONFIRMATION_FLAG = 16

$FOLDER_DATAFILES = "DataFiles"
$FOLDER_PATCHES = "Patches"
$FOLDER_UPDATES = "Updates"
$mutex = New-Object System.Threading.Mutex($false, "WriteMsgDownload")

function Display-Line([string] $msg, [Boolean] $addNewLine = $false, [Boolean] $addFrontTab = $true, [int] $runNum = 0)
{
    $tab = "`t"
    if (!$addFrontTab) {$tab = ""}
    $result = $mutex.WaitOne()
    Write-Host "$tab$msg"
    if ($addNewLine)
    {
        Write-Host ""
    }
    $mutex.ReleaseMutex()

    Write-Line $msg $addNewLine $addFrontTab $runNum
}

function Write-Line([string] $msg, [Boolean] $addNewLine = $false, [Boolean] $addFrontTab = $true, [int] $runNum = 0)
{
    $tab = "`t"
    if (!$addFrontTab) {$tab = ""}
    $private:output = "$runNum : $tab$msg"
    $result = $mutex.WaitOne()
    #Intermediately get add-Content : Stream was not readable.
    #Add-Content $logPath "$runNum : $msg" -PassThru | Write-Host
    [System.IO.File]::AppendAllText($logPath, "$private:output`r`n")
    
    if ($addNewLine)
    {
        $private:output = "$runNum : "
        [System.IO.File]::AppendAllText($logPath, "$private:output`r`n")
    }
    $mutex.ReleaseMutex()
}

function Display-Msg([string] $action, [string] $msg, [string] $status = "Completed")
{
    Display-Line ""
    Display-Line "#######################################" $false $false
    Display-Line $action":" $true $false
    Display-Line "$msg" $true
    Display-Line $status
    Display-Line "#######################################" $true $false
}

function Init-MSI
{
    $cp = New-Object CodeDom.Compiler.CompilerParameters
    $cp.CompilerOptions = "/unsafe"
    $cp.WarningLevel = 4
    $cp.TreatWarningsAsErrors = $true

    [string]$code =  @"  
    using System;
    //using System.ComponentModel;
    //using System.Diagnostics.CodeAnalysis;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Globalization;

    namespace ST.Version
    {
        public static class NativeMethods
        {
            [DllImport("msi.dll")]
            private static extern UInt32 MsiCloseHandle(UInt32 hAny);

            [DllImport("msi.dll", CharSet = CharSet.Unicode)]
            private static extern UInt32 MsiDatabaseOpenView(UInt32 hDatabase, String szQuery, out UInt32 phView);

            [DllImport("msi.dll", CharSet = CharSet.Unicode)]
            private static extern UInt32 MsiOpenDatabase(String szDatabasePath, IntPtr szPersist, out UInt32 phDatabase);

            [DllImport("msi.dll", CharSet = CharSet.Unicode)]
            private static extern UInt32 MsiRecordGetString(UInt32 hRecord, UInt32 iField, StringBuilder szValueBuf, ref UInt32 pcchValueBuf);

            [DllImport("msi.dll")]
            private static extern UInt32 MsiViewExecute(UInt32 hView, UInt32 hRecord);

            [DllImport("msi.dll")]
            private static extern UInt32 MsiViewFetch(UInt32 hView, out UInt32 phRecord);
            
            public static System.Version GetWindowsInstallerFileVersion(String fileName)
            {
                UInt32 db;
                var error = NativeMethods.MsiOpenDatabase(fileName, IntPtr.Zero /*MSIDBOPEN_READONLY*/, out db);
                if (error != 0)
                {
                    //throw new Win32Exception((Int32)error);
                    throw new Exception(String.Format(CultureInfo.InvariantCulture, "MsiOpenDatabase - Error: {0}", error));
                }

                UInt32 view = 0;
                UInt32 record = 0;
                try
                {
                    error = NativeMethods.MsiDatabaseOpenView(db, "SELECT Value FROM Property WHERE Property = 'ProductVersion'", out view);
                    if (error != 0)
                    {
                        //throw new Win32Exception((Int32)error);
                        throw new Exception(String.Format(CultureInfo.InvariantCulture, "MsiDatabaseOpenView - Error: {0}", error));
                    }

                    error = NativeMethods.MsiViewExecute(view, 0);
                    if (error != 0)
                    {
                        //throw new Win32Exception((Int32)error);
                        throw new Exception(String.Format(CultureInfo.InvariantCulture, "MsiViewExecute - Error: {0}", error));
                    }

                    error = NativeMethods.MsiViewFetch(view, out record);
                    if (error != 0)
                    {
                        //throw new Win32Exception((Int32)error);
                        throw new Exception(String.Format(CultureInfo.InvariantCulture, "MsiViewFetch - Error: {0}", error));
                    }

                    var buffer = new StringBuilder();
                    buffer.Capacity = 64;
                    var size = (UInt32)buffer.Capacity;
                    error = NativeMethods.MsiRecordGetString(record, 1, buffer, ref size);
                    if (error != 0)
                    {
                        //throw new Win32Exception((Int32)error);
                        throw new Exception(String.Format(CultureInfo.InvariantCulture, "MsiRecordGetString - Error: {0}", error));
                    }

                    return new System.Version(buffer.ToString());
                }
                finally
                {
                    if (record != 0)
                    {
                        NativeMethods.MsiCloseHandle(record);
                    }

                    if (view != 0)
                    {
                        NativeMethods.MsiCloseHandle(view);
                    }

                    NativeMethods.MsiCloseHandle(db);
                }
            }
        }
    }
"@
    Add-Type -CompilerParameters $cp -TypeDefinition $code
}

$downloadFileScriptBlock = {
    Param (
        [int]$runNum,
        [int]$totalCount,
        [string]$uri,
        [string]$patchesPath,
        [string]$hash,
        [boolean]$replace,
        [string]$logPath
    )

    $mutex = New-Object System.Threading.Mutex($false, "WriteMsgDownload")
        
    # Cache the user's display message and display it all at once, because multiple thread messages will be intermixed
    # It is ok to write the message to the log, because we can group log by thread id.
    $script:displayMsg = ""
    function Display-Line([string] $msg, [Boolean] $addNewLine = $false, [Boolean] $addFrontTab = $true)
    {
        $tab = "`t"
        if (!$addFrontTab) {$tab = ""}
        $script:displayMsg = "$script:displayMsg$tab$msg`r`n"
        $script:displayMsg
        if ($addNewLine)
        {
            $script:displayMsg = "$script:displayMsg`r`n"
            $script:displayMsg
        }
        Write-Line $msg $addNewLine $addFrontTab
    }

    function Write-Line([string] $msg, [Boolean] $addNewLine = $false, [Boolean] $addFrontTab = $true)
    {
        $tab = "`t"
        if (!$addFrontTab) {$tab = ""}
        $private:output = "$runNum : $tab$msg"
        $result = $mutex.WaitOne()
        #Intermediately get add-Content : Stream was not readable.
        #Add-Content $logPath "$private:output"
        [System.IO.File]::AppendAllText($logPath, "$private:output`r`n")
        
        if ($addNewLine)
        {
            $private:output = "$runNum : "
            [System.IO.File]::AppendAllText($logPath, "$private:output`r`n")
        }
        $mutex.ReleaseMutex()
    }
    
    function Flush-Msg
    {
        $result = $mutex.WaitOne()
        Write-Line "Flush-Msg: result: $result"
        Write-Host $script:displayMsg
        $mutex.ReleaseMutex()
    }

    function Delete-File()
    {
        Display-Line "Deleting patch: $patchesPath" $true
        if([System.IO.File]::Exists($patchesPath))
        {
            try
            {
                [System.IO.File]::Delete($patchesPath)
            }
            catch
            {
                $private:ex = $_.Exception.ToString()
                Display-Line "Deleting patch: $patchesPath failed: $private:ex" $true
            }
        }
        else
        {
            Display-Line "Deleting patch: $patchesPath does not exist." $true
        }
    }

    function Compare-FileMatchesHash([string] $expectedFilePath, [string] $base64Sha1)
    {
        try
        {
            Write-Line "Compare-FileMatchesHash - expectedFilePath: $expectedFilePath, base64Sha1: $base64Sha1"
            $expectedSha1 = [System.Convert]::FromBase64String($base64Sha1);
            $cryptoProvider = New-Object System.Security.Cryptography.SHA1CryptoServiceProvider
            $fileStream = [System.IO.File]::OpenRead($expectedFilePath)
            $computedSha1 = $cryptoProvider.ComputeHash($fileStream)
            if ((Compare-Object $computedSha1 $expectedSha1) -ne $null)
            {
                throw [System.Exception] "File's hash ($computedSha1) does not match expected hash ($expectedSha1)"
            }
            Display-Line "Compare file hash: $patchesPath matches digest" $true
        }
        finally
        {
            if ($fileStream -ne $null)
            {
                $fileStream.Dispose()
                $fileStream = $null
            }
        }
    }

    Display-Line "#######################################" $false $false
    Write-Line "runNum: `"$runNum`""
    Write-Line "totalCount: `"$totalCount`""
    Write-Line "uri: `"$uri`""
    Write-Line "patchesPath: `"$patchesPath`""
    Write-Line "hash: `"$hash`""
    Write-Line "replace: `"$replace`""
    Write-Line "logPath: `"$logPath`"" $true
    Display-Line "Processing File ($runNum of $totalCount): $uri" $true

    try
    {
        if ([System.IO.File]::Exists($patchesPath))
        {
            if ($replace)
            {
                Display-Line "Deleting File: $patchesPath" $true
                [System.IO.File]::Delete($patchesPath)
                Display-Line "Downloading: $uri to $patchesPath" $true
                (New-Object System.Net.WebClient).DownloadFile((New-Object System.Uri($uri)), $patchesPath)
                Write-Line "Done downloading replacement Patch"
            }
            else
            {
                Display-Line "Already downloaded: $uri to $patchesPath" $true
            }
        }
        else
        {
            Display-Line "Downloading: $uri to $patchesPath" $true
            (New-Object System.Net.WebClient).DownloadFile((New-Object System.Uri($uri)), $patchesPath)
            Write-Line "Done downloading Patch"
        }
        
        # If there is a Hash check the file again, use it otherwise just return true.
        if ([System.IO.File]::Exists($patchesPath) -and ![string]::IsNullOrEmpty($hash))
        {
            Write-Line "$patchesPath exists"
            # Compare-FileMatchesHash throws an exception if it does not match
            Compare-FileMatchesHash $patchesPath $hash
        }
        Display-Line "Success"
    }
    catch [Exception] 
    {
        Write-Line $_.Exception.ToString()
        Display-Line "Failed:"
        $private:ex = $_.Exception.ToString()
        Display-Line "`tError - $private:ex"
        
        Delete-File
    }
    try
    {
        Display-Line "#######################################" $true $false
        Flush-Msg
    }
    catch
    {
        Write-Line "Failed:"
        $private:ex = $_.Exception.ToString()
        Write-Line "`tError - $private:ex"
    }
    finally
    {
        if ($mutex -ne $null)
        {
            $mutex.Close()
        }
    }
}

function Create-Folder([string] $folder)
{
    if (![System.IO.Directory]::Exists($folder))
    {
        [System.IO.Directory]::CreateDirectory($folder) | Out-Null
        if ([System.IO.Directory]::Exists($folder))
        {
            Write-Line "Created folder: $folder" $true $false
        }
        else
        {
            throw [System.IO.DirectoryNotFoundException] "Directory does not exist: $folder"
        }
    }
}

function Test-Parameters()
{
    $private:error = $false
    $private:patchesFolderName = ""
    $private:msg
    $private:versionMajor = $version.Substring(0, 1)
    $script:versionURLPart = "v$private:versionMajor/${version}"
    switch ($product)
    {
        "isec"
        {
            $script:versionURLPart = "v${version}"
            $script:manifestFileNameZip = "protect.manifest.zip"
            $script:manifestFileNameCab = "protect.manifest.cab"
            $script:manifestFileNameXML = "protect.manifest.xml"
            $private:patchesFolderName = $FOLDER_PATCHES
        }
        "patch"
        {
            $script:manifestFileNameCab = "engines.manifest.cab"
            $script:manifestFileNameXML = "engines.manifest.xml"
            $private:patchesFolderName = $FOLDER_UPDATES
        }
        "oem"
        {
            if ([string]::IsNullOrEmpty($company))
            {
                $private:error = $true
                $private:msg = $private:msg + "`"$product`" requires a company name. Please supply -company `"genericCompany`"`r`n"
            }
            $script:versionURLPart = "${version}"
            $script:manifestFileNameCab = "partner.manifest.cab"
            $script:manifestFileNameXML = "partner.manifest.xml"
            $private:patchesFolderName = $FOLDER_PATCHES
        }
        default
        {
            $private:error = $true
            $private:msg = $private:msg + "`"$product`" is not supported.`r`n"
        }
    }

    if ($outDir.Length -eq 0)
    {
        $private:error = $true
        $private:msg = $private:msg + "You must specify an output directory.`r`n"
    }

    try
    {
        $script:dataFilesPath = [System.IO.Path]::Combine($outDir, $FOLDER_DATAFILES)
        Create-Folder ($script:dataFilesPath)
        $script:patchesPath = [System.IO.Path]::Combine($outDir, $private:patchesFolderName)
        Create-Folder ($script:patchesPath)
    }
    catch [System.IO.DirectoryNotFoundException]
    {
        $private:ex = $_.Exception.ToString()
        $private:msg = $private:msg + $private:ex + "`r`n"
    }

    if (!$doNOTDwnlDataFile)
    {
        if ([string]::IsNullOrEmpty($version))
        {
            $private:error = $true
            $private:msg = $private:msg + "Datafile download requires that a `$version be specifies.`r`n"
        }
    }
    
    if ($private:error)
    {
        throw [Exception] $private:msg
    }
}

function Download-File([string] $uri, [string] $dataFilesPath, [string] $type, [string] $hash)
{
    Display-Line "Downloading: $uri to $dataFilesPath" $true
    $webClient.DownloadFile((New-Object System.Uri($uri)), $dataFilesPath)
    Display-Line "Successfully downloaded: $uri to $dataFilesPath" $true
    Verify-DigitalSignature $dataFilesPath $type $hash
}

function Get-FilePath([String] $downloadUri, [string] $dataFilesPath)
{
    $private:fileName = $downloadUri.SubString($downloadUri.LastIndexOf('/')+1)
    $private:filePath = [System.IO.Path]::Combine($dataFilesPath, $fileName)
    return $filePath
}

function Extract-File([string] $filePath)
{
    if ([System.IO.Path]::GetExtension($filePath) -ieq ".cab")
    {
        Display-Line "Extracting: $filePath to $dataFilesPath" $true
        $container = $shell.NameSpace($filePath)
        $destination = $shell.Namespace($dataFilesPath)
        #SILENT_FLAG + $NOCONFIRMATION_FLAG switch do not suppress the dialog or prompt to replace. So, manually did it.
        if ($container.items() -ne $null)
        {
            foreach ($item in $container.items())
            {
                $destinationFilePath = [System.IO.Path]::Combine($dataFilesPath, $item.Name)
                if ([System.IO.File]::Exists($destinationFilePath))
                {
                    Write-Line "Deleting: $destinationFilePath to extract new file." $true
                    [System.IO.File]::Delete($destinationFilePath)
                }
                $destination.copyhere($item, $SILENT_FLAG + $NOCONFIRMATION_FLAG)
            }
        }
        else
        {
            Display-Line "$filePath does not contain any files to extract" $true
        }
        
        Display-Line "Successfully extracted: $filePath" $true
    }
}

function Replace-Neq1([Version] $inVersion)
{
    $private:outVersion = $inVersion
    # 7z.dll and .tar return -1 in either Build or/and Revision; therefore, the version object contain -1 in those value and the comparision fails.
    # Check to see if the values are -1 and replace them with 0
    if (($private:inVersion.Build -eq -1) -or ($private:inVersion.Revision -eq -1))
    {
        $private:build = $private:inVersion.Build
        $private:revision = $private:inVersion.Revision
        if ($private:build -eq -1) {$private:build = 0}
        if ($private:revision -eq -1) {$private:revision = 0}
        $private:outVersion = New-Object System.Version($private:inVersion.Major, $private:inVersion.Minor, $private:build, $private:revision)
    }

    return $private:outVersion
}

function Get-FileVersion([string] $filePath, [string] $type)
{
    $private:extension = [System.IO.Path]::GetExtension($filePath)
    Write-Line "extension: $private:extension"
    
    # I still need to use the extension, because engines.manifest.xml does not have type attribute for the packages section. Once that does, I can just use type
    switch ($private:extension)
    {
        ".msi"
        {
            $private:version = [ST.Version.NativeMethods]::GetWindowsInstallerFileVersion($filePath)
            break
        }
        ".zip"
        {
            try
            {
                switch ($type)
                {
                    "VersionedContainer"
                    {
                        $package = [System.IO.Packaging.Package]::Open($filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
                        #$package.RetrieveVersionInfo()
                        $private:version = $package.PackageProperties.Version
                        break
                    }
                    "SignedPackage"
                    {
                        $package = [ST.Engines.Packaging.SignedPackageAccessor]::Open($filePath)
                        $private:version = $package.Version
                        break
                    }
                    default
                    {
                        throw [System.Exception] "Unable to verify digital signature for file extension $private:extension of type $type. It is not supported"
                        break
                    }
                }
            }
            finally
            {
                if ($package -ne $null)
                {
                    $package.Dispose()
                    if ($type -ieq "VersionedContainer") { $package.Close() }
                    $package = $null
                }
            }
            break
        }
        { '.cab', '.exe', '.dll' -contains $_ }
        {
            $private:fileVersionInfo = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($filePath)
            $private:version = ([Version] $private:fileVersionInfo.FileVersion)
            break
        }
        ".obf"
        {
            Write-Line "Get-FileVerion: Did not implement" $true
            break
        }
        ".xml"
        {
            Write-Line "Get-FileVerion: Did not implement" $true
            break
        }
        ".tar"
        {
            $private:version = [ST.Engines.Catalog.Rpm.RpmVersionReader]::GetRpmVersionFromTarFile($filePath)
            break
        }
        default
        {
            throw [System.Exception] "Unable to get file version for file extension $private:extension. It is not supported"
            break
        }
    }
    return $private:version
}

function Determine-DownloadFile([string] $filePath, [Version] $manifestFileVersion, [string] $type)
{
    if ([System.IO.File]::Exists($filePath))
    {
        $private:fileVersion = Get-FileVersion $filePath $type
        Write-Line "private:fileVersion (Before): `"$private:fileVersion`", manifestFileVersion: `"$manifestFileVersion`""
        $private:fileVersion = Replace-Neq1 $private:fileVersion
        $manifestFileVersion = Replace-Neq1 $manifestFileVersion
        Write-Line "private:fileVersion (After): `"$private:fileVersion`", manifestFileVersion: `"$manifestFileVersion`""
        
        #if there is no file version, determine how protect determine weather or not to download our xml / zip, else check the file version.
        #If they do not match, delete and re-download.
        if ($private:fileVersion -eq $manifestFileVersion)
        {
            Display-Line "File version matches. Not downloading." $true
            return $false
        }
        else
        {
            Write-Line "Deleting: $filePath for re-download" $true
            [System.IO.File]::Delete($filePath)
        }
    }
    
    return $true
}

function Download-Manifest([string] $versionFileUri, [string] $versionFileCAB, [string] $versionFileXML, [string] $dataFilesPath, [bool] $throwForbiddenEx)
{
    Display-Line "#######################################" $false $false
    Display-Line "Processing File: $private:versionFileUri" $true
    try
    {
        $private:fileCAB = [System.IO.Path]::Combine($script:dataFilesPath, $private:versionFileCAB)
        $private:fileXML = [System.IO.Path]::Combine($script:dataFilesPath, $private:versionFileXML)
        Download-File -uri $private:versionFileUri -dataFilesPath $private:fileCAB "Cab" ""
        Extract-File $private:fileCAB
        Display-Line "Success"
        Display-Line "#######################################" $true $false
        
        Get-DataFiles -manifestPath $private:fileXML -dataFilesPath $private:dataFilesPath
    }
    catch [Exception]
    {
        Display-Line "Failed:"
        $private:ex = $_.Exception.ToString()
        Display-Line "`tError - $private:ex"
        #Continue with other manifests or patch files
        #throw $_
        Display-Line "#######################################" $true $false

        #Since AWS is case sensitive, throw Forbidden execption in order to try other urls.
        if ($throwForbiddenEx -and $_.Exception.Response -ne $null -and $_.Exception.Response.StatusCode -eq [System.Net.HttpStatusCode]::Forbidden)
        {
            throw;
        }
    } 
}

function Get-Manifest ([System.Xml.XmlDocument] $versions)
{
    switch ($product) 
    {
        "isec"
        {
            return $versions.manifest
        }
        {($_ -eq "patch")}
        {
            return $versions.protectManifest
        }
        "oem"
        {
            return $versions.partnerManifest
        }
        default
        {
            throw [System.Exception] "Unable to Manifest for `"$product`" product . It is not supported"
            return
        }
    }
}

function Get-DataFiles([string] $manifestPath, [string] $dataFilesPath)
{
    $private:versions = New-Object xml
    $private:versions.Load([System.IO.Path]::GetFullPath($manifestPath))
    $private:manifest = Get-manifest($private:versions)
    $private:manifestPackages = $private:manifest.packages.package
    
    if ($manifest.files.file -ne $null)
    {
        foreach ($f in $manifest.files.file)
        {
            $private:downloadUri = $f.downloadUri
            $private:filePath = Get-FilePath -downloadUri $private:downloadUri -dataFilesPath $dataFilesPath
            $private:type = $f.type
            $private:hash = $f.digest.value
            if ($f.digest.value -eq $null)
            {
                $private:hash = [string]::Empty
            }
            Display-Line "#######################################" $false $false
            Display-Line "Processing File: $private:downloadUri" $true
            
            try
            {
                if (Determine-DownloadFile -filePath $filePath -manifestFileVersion $f.version -type $private:type)
                {
                    #For file that are binary type, you need to download the cab and extract it.
                    if ($f.packageRef)
                    {
                        $private:manifestPackage = ($private:manifestPackages | Where-Object {$_.key -eq $f.packageRef })
                        $private:downloadUri = $private:manifestPackage.downloadUri
                        $private:filePath = Get-FilePath -downloadUri $private:downloadUri -dataFilesPath $dataFilesPath
                        $private:type = $private:manifestPackage.type
                    }
                    Download-File -uri $private:downloadUri -dataFilesPath $private:filePath $private:type $private:hash
                    Extract-File $private:filePath
                }

                Display-Line "Success"
            }
            catch [Exception]
            {
                Display-Line "Failed:"
                $private:ex = $_.Exception.ToString()
                Display-Line "`tError - $private:ex"
                #Continue to process other data files.
                #throw $_
            }  
            finally
            {
                Display-Line "#######################################" $true $false
            }
        }
    }
    else
    {
        Display-Line "Manifest does not contain any files" $true
    }

    if ($manifest.windowsPrerequisites.windowsPrerequisite -ne $null)
    {
        foreach ($prereq in $manifest.windowsPrerequisites.windowsPrerequisite)
        {
            $private:downloadUri = $prereq.downloadLocations.downloadLocation.url
            $private:filePath = Get-FilePath -downloadUri $private:downloadUri -dataFilesPath $dataFilesPath
            $private:type = $prereq.type
            $private:hash = $prereq.digest.value
            if ($f.digest.value -eq $null)
            {
                $private:hash = [string]::Empty
            }
            Display-Line "#######################################" $false $false
            Display-Line "Processing Windows Prerequisite: $private:downloadUri" $true
            
            try
            {
                if (Determine-DownloadFile -filePath $filePath -manifestFileVersion $prereq.version -type $private:type)
                {
                    Download-File -uri $private:downloadUri -dataFilesPath $private:filePath $private:type $private:hash
                    Extract-File $private:filePath
                }

                Display-Line "Success"
            }
            catch [Exception]
            {
                Display-Line "Failed:"
                $private:ex = $_.Exception.ToString()
                Display-Line "`tError - $private:ex"
                #Continue to process other data files.
                #throw $_
            }
            finally
            {
                Display-Line "#######################################" $true $false
            }
        }
    }
    else
    {
        Display-Line "Manifest does not contain any windows Prerequisites" $true
    }

    #Process any referenced manifests
    $private:referencedManifest = $manifest.referencedManifests.referencedManifest
    if ($private:referencedManifest -ne $null)
    {
        foreach ($r in $private:referencedManifest)
        {
            Download-Manifest -versionFileUri $r.cabSource -versionFileCAB $r.cabName -versionFileXML $r.xmlName -dataFilesPath $script:dataFilesPath -throwForbiddenEx $false
        }
    }
}

function Get-DownloadItems()
{
    switch ($product)
    { 
        {($_ -eq "isec")}
        {
            return Import-Csv -Path $downloadPackageInputFilePath -Header Source,FileName,PackageId,Digest
        }
        "patch"
        {
            $private:xmlFile = New-Object xml
            $private:xmlFile.Load($downloadPackageInputFilePath)
            return $private:xmlFile.ArrayOfDownloadItem.DownloadItem
        }
        "oem"
        {
            Display-Line "Downloading patches are not supported for OEM partners" $true
            return $null
        }
    }
    return @()
}

function Download-Patches([string] $patchesPath, [Boolean] $replace)
{
    # If the download package input file exist download patches
    if ($downloadPackageInputFilePath.Length -gt 0)
    {
        if ([System.IO.File]::Exists($downloadPackageInputFilePath))
        {
            Display-Line "Preparing patch download" $true

            $i=1
            $jobs = @()
            $sessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
            $runspacePool = [RunspaceFactory]::CreateRunspacePool(1, $numThreads, $sessionState, $Host)
            $runspacePool.Open()
            
            $downloadItems = @(Get-DownloadItems)
            $totalCount = $downloadItems.Count
            
            Display-Line "Downloading patches ..." $true
            if ($downloadItems -ne $null)
            {
                foreach ($downloadItem in $downloadItems)
                {
                    try
                    {
                        $source = $downloadItem.Source
                        $hash = $downloadItem.Digest
                        Write-Line "#######################################" $false $false
                        Write-Line "Creating job: $source" $true
                        
                        $packageDirectory = [System.IO.Path]::Combine($patchesPath, $downloadItem.PackageId)
                        $filePath = [System.IO.Path]::Combine($packageDirectory, $downloadItem.FileName)
                        Create-Folder ($packageDirectory)
                        Write-Line "runNum: $i"
                        Write-Line "totalCount: $totalCount"
                        Write-Line "source: $source"
                        Write-Line "filePath: $filePath"
                        Write-Line "hash: $hash"

                        $job = [powershell]::Create().AddScript($downloadFileScriptBlock).AddParameter("runNum", $i++).AddParameter("totalCount", $totalCount).AddParameter("uri", $source).AddParameter("patchesPath", $filePath).AddParameter("hash", $hash).AddParameter("replace", $replace).AddParameter("logPath", $logPath)
                        Write-Line "Created job"
                        $job.RunspacePool = $runspacePool
                        Write-Line "Associated runspace pool"
                        $jobs += New-Object PSObject -Property @{
                            #RunNum = $i++
                            Name = $filePath
                            Handle = $job.BeginInvoke()
                            Thread = $job
                        }
                        Write-Line "Create job Success"
                    }
                    catch [Exception] 
                    {
                        $private:ex = $_.Exception.ToString()
                        Display-Line "Create job Failed: $source`n`n`t`tError - $private:ex"
                    }
                    finally
                    {
                        Write-Line "#######################################" $true $false
                    }
                }
            }
            else
            {
                Display-Msg -action "Patch not downloaded" "Patch download was not done, because the input file does not have any patches to download. Verify that $downloadPackageInputFilePath contains patch data."
            }
            
            Do {
               Start-Sleep -Seconds 1
            } While ( $jobs.Handle.IsCompleted -contains $false) #Jobs.Handle is a collection
            
            $runspacePool.Dispose()
            $runspacePool = $null
            Display-Line "Completed patch download" $true
        }
        else
        {
            Display-Msg -action "Patch not downloaded" "Patch download was not done, because the input file does not exist. Verify that $downloadPackageInputFilePath exists."
        }
    }
    else
    {
        Display-Msg -action "Patch not downloaded" "Patch download will not be done, because no input file was supplied. Please set `$downloadPackageinputFilePath if you would like to download patches."
    }
}

function Verify-DigitalSignature([string] $filePath, [string] $type, [string] $hash)
{
    if (![System.IO.File]::Exists($filePath))
    {
        # only files that exist can be valid
        Display-Msg -action "$filePath does not exist"
        throw [System.IO.FileNotFoundException] "$filePath"
    }

    $private:extension = [System.IO.Path]::GetExtension($filePath)
    
    # I still need to use the extension, because engines.manifest.xml does not have type attribute for the packages section. Once that does, I can just use type
    switch ($private:extension)
    {
        ".zip"
        { 
            switch ($type)
            {
                "VersionedContainer"
                {
                    Verify-DigitalSignatureZip $private:filePath
                    break
                }
                "SignedPackage"
                {
                    Verify-DigitalSignatureLinux $private:filePath
                    break
                }
                default
                {
                    throw [System.Exception] "Unable to verify digital signature for file extension $private:extension of type $type. It is not supported"
                    break
                }
            }
            
            break
        }
        { '.cab', '.exe', '.dll', '.msi' -contains $_ }
        {
            Verify-DigitalSignatureExecutables $private:filePath
            break
        }
        ".obf"
        {
            Write-Line "Verify-DigitalSignature: Did not implement" $true
            break
        }
        ".tar"
        {
            Verify-DigitalSignatureTar $private:filePath $hash
            break
        }
        default
        {
            throw [System.Exception] "Unable to verify digital signature for file extension $private:extension. It is not supported"
            break
        }
    }
}

function Verify-DigitalSignatureExecutables([string] $filePath)
{
    Display-Line "Verifying Digital Signature (Executables) of $private:filePath." $true
    $private:signature = Get-AuthenticodeSignature $filePath
    $private:status = $private:signature.Status
    $private:thumbprint = $private:signature.SignerCertificate
    Write-Line "thumbprint: $private:thumbprint"
    Write-Line "status: $private:status" $true
    if ($private:status -ine "Valid")
    {
        [System.IO.File]::Delete($private:filePath)
        throw [System.InvalidOperationException]([String]::Format([System.Globalization.CultureInfo]::CurrentCulture, "Certificate verification failed: {0}", $private:status))
    }
    Display-Line "Successfully verified: $private:filePath" $true
}

function Verify-DigitalSignatureZip([string] $filePath)
{
    Display-Line "Verifying Digital Signature (Zip) of $private:filePath." $true
    [System.IO.Packaging.Package] $private:package = $null
    try
    {
        $private:package = [System.IO.Packaging.Package]::Open($private:filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
        [System.IO.Packaging.PackageDigitalSignatureManager] $private:dsm = [System.IO.Packaging.PackageDigitalSignatureManager]($private:package)

        #// Verify the collection of certificates in the package
        if ($private:dsm.Signatures -ne $null)
        {
            foreach ($private:signature in $private:dsm.Signatures)
            {
                $private:thumbprint = $private:signature.Signer.Thumbprint
                Write-Line "thumbprint: $private:Thumbprint"
                [System.Security.Cryptography.X509Certificates.X509ChainStatusFlags] $private:flags = [System.IO.Packaging.PackageDigitalSignatureManager]::VerifyCertificate($private:signature.Signer)
                Write-Line "flags: $private:flags" $true
                if ($private:flags -ne [System.Security.Cryptography.X509Certificates.X509ChainStatusFlags]::NoError -and
                    $private:flags -ne [System.Security.Cryptography.X509Certificates.X509ChainStatusFlags]::RevocationStatusUnknown -and
                    $private:flags -ne [System.Security.Cryptography.X509Certificates.X509ChainStatusFlags]::OfflineRevocation)
                {
                    [System.IO.File]::Delete($private:filePath)
                    throw [System.InvalidOperationException]([String]::Format([System.Globalization.CultureInfo]::CurrentCulture, "Certificate verification failed - flags: {0}", $private:flags))
                }
            }
        }
        else
        {
            [System.IO.File]::Delete($private:filePath)
            throw [System.InvalidOperationException] "$private:filePath does not have any signature"
        }
    }
    finally
    {
        if ($private:package -ne $null)
        {
            $private:package.Close()
        }
    }
    Display-Line "Successfully verified: $private:filePath" $true
}

function Verify-DigitalSignatureLinux([string] $filePath)
{
    Display-Line "Verifying Digital Signature (Linux) of $private:filePath." $true
    try
    {
        $accessor = [ST.Engines.Packaging.SignedPackageAccessor]::Open($filePath)
        if ($accessor.VerifyCertificatesAndSignatures() -eq $false)
        {
            [System.IO.File]::Delete($private:filePath)
            throw [System.InvalidOperationException]([String]::Format([System.Globalization.CultureInfo]::CurrentCulture, "Certificate verification failed."))
        }
        Display-Line "Successfully verified: $private:filePath" $true
    }
    finally
    {
        if ($accessor -ne $null)
        {
            $accessor.Dispose()
            $accessor = $null
        }
    }
}

function Verify-DigitalSignatureTar([string] $expectedFilePath, [string] $base64Sha1)
{
    Display-Line "Verifying Digital Signature (Tar) of $expectedFilePath." $true
    try
    {
        Write-Line "Verify-DigitalSignatureTar - expectedFilePath: $expectedFilePath, base64Sha1: $base64Sha1" $true
        $expectedSha1 = [System.Convert]::FromBase64String($base64Sha1);
        $cryptoProvider = [System.Security.Cryptography.Sha256]::Create()
        $fileStream = [System.IO.File]::OpenRead($expectedFilePath)
        $computedSha1 = $cryptoProvider.ComputeHash($fileStream)
        if ((Compare-Object $computedSha1 $expectedSha1) -ne $null)
        {
            throw [System.Exception] "File's hash ($computedSha1) does not match expected hash ($expectedSha1)"
        }
        Display-Line "Successfully verified: $expectedFilePath" $true
    }
    finally
    {
        if ($fileStream -ne $null)
        {
            $fileStream.Dispose()
            $fileStream = $null
        }
    }
}

#####################################
#   Start Script
#####################################
cls

[System.Net.ServicePointManager]::SecurityProtocol = `
    [System.Net.SecurityProtocolType]::Tls11, 
    [System.Net.SecurityProtocolType]::Tls12, 
    [System.Net.SecurityProtocolType]::Tls;

$script:dataFilesPath = ""
$script:patchesPath = ""
$currentFolder = split-path $SCRIPT:MyInvocation.MyCommand.Path -parent
$scriptFileNameWithoutExt = [System.IO.Path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Name)
$logPath = [System.IO.Path]::Combine($outDir, "${scriptFileNameWithoutExt}_Trace.log")
    
try
{
    $cmdLine = ""
    $product = $product.Trim().ToLower()
    $userAgent = "Disconnected Download - $product/$version"
    foreach ($key in $MyInvocation.BoundParameters.keys)
    {
        $value = (get-variable $key).Value
        if ($value.GetType() -eq [String])
        {
            $private:cmdLine = $private:cmdLine + "-$key `"$value`" "
        }
        else
        {
            $private:cmdLine = $private:cmdLine + "-$key $value "
        }
    }
    
    try
    {
        Create-Folder ($outDir)
    }
    catch [System.IO.DirectoryNotFoundException]
    {
        $private:ex = $_.Exception.ToString()
        $private:msg = $private:msg + $private:ex + "`r`n"
    }
    
    $currentDateTime = [DateTime]::UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffffff") + "z"
    Display-Line "#######################################" $false $false
    Display-Line "Version: 9.4.0.0"
    Display-Line "Date Time: $currentDateTime"
    Display-Line ("PowerShell Version: " + $PSVersionTable.PSVersion)
    Display-Line "Product: $product"
    Display-Line "Output Directory: `"$outDir`""
    Display-Line "Do NOT Download DataFiles: $doNOTDwnlDataFile"
    Display-Line "Replace All DataFiles: $dwnlAllDataFile"
    Display-Line "Version: `"$version`""
    Display-Line "Patch download input file path: `"$downloadPackageInputFilePath`""
    Display-Line "Replace Patch Files: $replacePatchFile"
    Display-Line "Number of thread: $numThreads"
    Display-Line "Company: `"$company`""
    Display-Line "Overwrite Manifest Download URL: `"$overwriteManifestDownloadURL`""
    Display-Line "Data files directory: `"$script:dataFilesPath`""
    Display-Line "Patch files directory: `"$script:patchesPath`"" $true
    Display-Line "Command line: $cmdLine"
    Display-Line "User Agent: `"$userAgent`""
    Display-Line "#######################################" $true $false

    Test-Parameters

    Add-Type -AssemblyName WindowsBase
    Add-Type -Path $([IO.Path]::Combine($pwd, "$currentFolder\ST.Core.dll"))
    Add-Type -Path $([IO.Path]::Combine($pwd, "$currentFolder\ST.Engines.dll"))
    Add-Type -Path $([IO.Path]::Combine($pwd, "$currentFolder\ST.Engines.Packaging.dll"))
    Add-Type -Path $([IO.Path]::Combine($pwd, "$currentFolder\ST.Engines.Catalog.dll"))
    
    Init-MSI
    
    $webClient = New-Object System.Net.WebClient
    $webClient.Headers.Add([System.Net.HttpRequestHeader]::UserAgent, $userAgent);
    
    if (!$doNOTDwnlDataFile)
    {
        $shell = New-Object -com shell.application
        
        if ($dwnlAllDataFile)
        {
            #Customer were getting datafile download errors and not realizing it. So, they keep copying the same datafiles over and over again
            foreach($file in [System.IO.Directory]::GetFiles($script:dataFilesPath)){[System.IO.File]::Delete($file)}
        }
        
        $private:versionFileUri = $overwriteManifestDownloadURL.Trim()
        if ([string]::IsNullOrEmpty($private:versionFileUri))
        {
            $attempts = 0
            # AWS is case sensitive. So, try both upper and lower first character casing
            $productList = @()
            $firstLetter = $product.get_Chars(0).ToString()
            $productList += $firstLetter.ToLower() + $product.SubString(1)
            $productList += $firstLetter.ToUpper() + $product.SubString(1)
            
            $companyList = @()
            if (![string]::IsNullOrEmpty($company))
            {
                $firstLetter = $company.get_Chars(0).ToString()
                $companyList += $firstLetter.ToUpper() + $company.SubString(1)
                $companyList += $firstLetter.ToLower() + $company.SubString(1)
            }
            
            :product foreach ($prod in $productList)
            {
                if ([string]::IsNullOrEmpty($company))
                {
                    try
                    {
                        $attempts++
                        $private:versionFileUri = "http://content.ivanti.com/data/$prod/$script:versionURLPart/manifest/$script:manifestFileNameCab"
                        Display-Msg -action "Download attempt ($attempts)" "Trying $private:versionFileUri" ""
                        Download-Manifest -versionFileUri $private:versionFileUri -versionFileCAB $script:manifestFileNameCab -versionFileXML $script:manifestFileNameXML -dataFilesPath $script:dataFilesPath -throwForbiddenEx $true
                        break product
                    }
                    catch [System.Net.WebException]
                    {
                        #All exceptions are handled in Download-Manifest unless -throwForbiddenEx $true, then the forbidden errors are thrown up. Just write them to the log.
                        $private:ex = $_.Exception.ToString()
                        Write-Line "Download Failed - Error - $private:ex" $true
                    }
                }
                else
                {
                    foreach ($comp in $companyList)
                    {
                        try
                        {
                            $attempts++
                            switch ($product)
                            {
                                "oem"
                                {
                                    $private:versionFileUri = "http://content.ivanti.com/data/$prod/${comp}/data/$script:versionURLPart/manifest/$script:manifestFileNameCab"
                                }
                                default
                                {
                                    $private:versionFileUri = "http://content.ivanti.com/data/$prod/$script:versionURLPart${comp}/manifest/$script:manifestFileNameCab"
                                }
                            }
                            Display-Msg -action "Download attempt ($attempts)" "Trying $private:versionFileUri" ""
                            Download-Manifest -versionFileUri $private:versionFileUri -versionFileCAB $script:manifestFileNameCab -versionFileXML $script:manifestFileNameXML -dataFilesPath $script:dataFilesPath -throwForbiddenEx $true
                            break product
                        }
                        catch [System.Net.WebException]
                        {
                            #All execptions are handled in Download-Manifest unless -throwForbiddenEx $true, then the forbidden errors are thrown up. Just write them to the log.
                            $private:ex = $_.Exception.ToString()
                            Write-Line "Download Failed - Error - $private:ex" $true
                        }
                    }
                }
            }
        }
        else
        {
            Download-Manifest -versionFileUri $private:versionFileUri -versionFileCAB $script:manifestFileNameCab -versionFileXML $script:manifestFileNameXML -dataFilesPath $script:dataFilesPath -throwForbiddenEx $false
        }
    }
    else
    {
        Display-Msg -action "DataFile not download" "DataFiles download will not be done, because `$doNOTDwnlDataFile was supplied."
    }
    
    Download-Patches -patchesPath $script:patchesPath -replace $replacePatchFile
    Display-Msg -action "Download Completed" -msg "The output directory is $outDir. Check for any errors above."
}
catch
{
    $private:ex = $_.Exception.ToString()
    Display-Msg -action "Download Failed" -msg "Error - $private:ex"
}
finally
{
    if ($mutex -ne $null)
    {
        $mutex.Close()
    }
    if ($webClient -ne $null)
    {
        $webClient.Dispose();
        $webClient = $null;
    }
}

# SIG # Begin signature block
# MIIafwYJKoZIhvcNAQcCoIIacDCCGmwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA6dwMfm0m7P+DI
# kvtvAzTZ07TfEiTTddaZKKOZ2WksCaCCClwwggUkMIIEDKADAgECAhADaYn+wFY7
# B6fgEzB//5WCMA0GCSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNV
# BAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcN
# MjAwNDAzMDAwMDAwWhcNMjMwNjE0MTIwMDAwWjBhMQswCQYDVQQGEwJVUzENMAsG
# A1UECBMEVXRhaDEVMBMGA1UEBxMMU291dGggSm9yZGFuMRUwEwYDVQQKEwxJdmFu
# dGksIEluYy4xFTATBgNVBAMTDEl2YW50aSwgSW5jLjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAMdHOcdZHILVe+j/PEKdcgxIsNT8QWdkknMjkCd5hWRK
# b27Oxpu4KA5zMip2ORS0dCCf8spgWfg86tfR33NFI528cZLJWOtpjCwU4FDLMZlO
# kghtsXV/621qgUC3SuZ5ro4/OBxjVjZUUsE5SYP7lhiGSP+Af+BHITvjb+rZUSru
# XgxCnVJfHMmAfMx8axztSaM6itoJHTvvo4gKijR58p9D4ExY0Khr2ZiwGYJKbevu
# 22poRPWr3bEQFg+e8m3N+/sef9nbWm991r48N+L+F0x+CHOipqULWwrJ9KCLw+qa
# zBKRVlvQzV2LKmI6fv1CyZ8jRX/OayUJjk1gk3wQ0LcCAwEAAaOCAcUwggHBMB8G
# A1UdIwQYMBaAFFrEuXsqCqOl6nEDwGD5LfZldQ5YMB0GA1UdDgQWBBSIbr+XNBZA
# EW6wFeOECavL9J6a7jAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUH
# AwMwdwYDVR0fBHAwbjA1oDOgMYYvaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL3No
# YTItYXNzdXJlZC1jcy1nMS5jcmwwNaAzoDGGL2h0dHA6Ly9jcmw0LmRpZ2ljZXJ0
# LmNvbS9zaGEyLWFzc3VyZWQtY3MtZzEuY3JsMEwGA1UdIARFMEMwNwYJYIZIAYb9
# bAMLMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMw
# CAYGZ4EMAQQBMIGEBggrBgEFBQcBAQR4MHYwJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBOBggrBgEFBQcwAoZCaHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0U0hBMkFzc3VyZWRJRENvZGVTaWduaW5nQ0EuY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggEBAPP67cYMvFgX2x7E+b8A
# 52RvGcTQi9u6lNusGkHXRn0HFCIvnU//bki9YpzbrTJSrNxYbEBbojslT/eJDD2P
# D54jOD6n7M/u3SM00g1rddNqFCX68/W3p8JvJ13BOS/W2aGaq5saLGd2mb7ke8Ub
# ymwdkDNQC8/U/p9XP3uOUCb92darIYOSWwYCSHFTefGcjnUEIvuTzFJJGgRrBlzL
# 8QIEl1Q5HU046YBAXfD5vMF3Kc3no/tuEl7gJauxv4jqg58JoSbEGsZPzQC10zdf
# UMKSxeqLS3ALjf8VxilBD9u06YKXM2BYz7h/htzIaP631zBTdPoQLQNzugxkOGya
# FHQwggUwMIIEGKADAgECAhAECRgbX9W7ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUA
# MGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsT
# EHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQg
# Um9vdCBDQTAeFw0xMzEwMjIxMjAwMDBaFw0yODEwMjIxMjAwMDBaMHIxCzAJBgNV
# BAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdp
# Y2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2Rl
# IFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQD407Mc
# fw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/lqJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnX
# tqrwnIal2CWsDnkoOn7p0WfTxvspJ8fTeyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7
# JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqHCN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvO
# f+l8y5Kh5TsxHM/q8grkV7tKtel05iv+bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061
# xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLoLFH3c7y9hbFig3NBggfkOItqcyDQD2Rz
# PJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIByTASBgNVHRMBAf8ECDAGAQH/AgEAMA4G
# A1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDAzB5BggrBgEFBQcBAQRt
# MGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEF
# BQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNydDCBgQYDVR0fBHoweDA6oDigNoY0aHR0cDovL2NybDQuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDA6oDigNoY0aHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNy
# bDBPBgNVHSAESDBGMDgGCmCGSAGG/WwAAgQwKjAoBggrBgEFBQcCARYcaHR0cHM6
# Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAKBghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5
# eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNt
# yA8wDQYJKoZIhvcNAQELBQADggEBAD7sDVoks/Mi0RXILHwlKXaoHV0cLToaxO8w
# Ydd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGSdQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut
# 119EefM2FAaK95xGTlz/kLEbBw6RFfu6r7VRwo0kriTGxycqoSkoGjpxKAI8LpGj
# wCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo+MUSaJ/PQMtARKUT8OZkDCUIQjKyNook
# Av4vcn4c10lFluhZHen6dGRrsutmQ9qzsIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQ
# BvwHgfqL2vmCSfdibqFT+hKUGIUukpHqaGxEMrJmoecYpJpkUe8xgg95MIIPdQIB
# ATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgQ29kZSBTaWduaW5nIENBAhADaYn+wFY7B6fgEzB//5WCMA0GCWCG
# SAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcN
# AQkEMSIEIH2bSz8ONvbaEF1ypFioi9hLarDd4rgboJHjg8YZ332GMA0GCSqGSIb3
# DQEBAQUABIIBAHxF7K7Nwweglyf75+m0DEamjAcWsfMR2lV2kvg0PdjuVhbaQkCX
# rP5zHlPBPLEF//nF5dx0rAeevMDjaLDii1BRmXFo5ZE3ylVRv6mnguKC9M1S1SR8
# VP68yX2Qor0Se9Hex0XrClCTumWiYMz8qlF/01VzyBZhOXmXN0nLMb0trr3EIFxQ
# 3Udy+bUYdMrAKggVDj8fbIOYsVhC7d77h2CWN0aCuNw0uxFyi6iOkrZj6e53mUKx
# wiKnsH2ewyqDH/Xncu15oZLMRMhDSg5IDdLDxWvNTMgLNgywRcU310ddedESaj1u
# Rs22q4gp5wsNb8FiPxc95ITeisUoIiOlCG6hgg1FMIINQQYKKwYBBAGCNwMDATGC
# DTEwgg0tBgkqhkiG9w0BBwKggg0eMIINGgIBAzEPMA0GCWCGSAFlAwQCAQUAMHgG
# CyqGSIb3DQEJEAEEoGkEZzBlAgEBBglghkgBhv1sBwEwMTANBglghkgBZQMEAgEF
# AAQg/OrGjhPV6NozM8aYnT0ccZZttp7CSsfi/rdBwSA3ve0CEQClyQbN+0JVHWGC
# 46kGmpaRGA8yMDIxMDIwMTIxMzY1NVqgggo3MIIE/jCCA+agAwIBAgIQDUJK4L46
# iP9gQCHOFADw3TANBgkqhkiG9w0BAQsFADByMQswCQYDVQQGEwJVUzEVMBMGA1UE
# ChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYD
# VQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBMB4X
# DTIxMDEwMTAwMDAwMFoXDTMxMDEwNjAwMDAwMFowSDELMAkGA1UEBhMCVVMxFzAV
# BgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMSAwHgYDVQQDExdEaWdpQ2VydCBUaW1lc3Rh
# bXAgMjAyMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMLmYYRnxYr1
# DQikRcpja1HXOhFCvQp1dU2UtAxQtSYQ/h3Ib5FrDJbnGlxI70Tlv5thzRWRYlq4
# /2cLnGP9NmqB+in43Stwhd4CGPN4bbx9+cdtCT2+anaH6Yq9+IRdHnbJ5MZ2djpT
# 0dHTWjaPxqPhLxs6t2HWc+xObTOKfF1FLUuxUOZBOjdWhtyTI433UCXoZObd048v
# V7WHIOsOjizVI9r0TXhG4wODMSlKXAwxikqMiMX3MFr5FK8VX2xDSQn9JiNT9o1j
# 6BqrW7EdMMKbaYK02/xWVLwfoYervnpbCiAvSwnJlaeNsvrWY4tOpXIc7p96AXP4
# Gdb+DUmEvQECAwEAAaOCAbgwggG0MA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8E
# AjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMEEGA1UdIAQ6MDgwNgYJYIZIAYb9
# bAcBMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAf
# BgNVHSMEGDAWgBT0tuEgHf4prtLkYaWyoiWyyBc1bjAdBgNVHQ4EFgQUNkSGjqS6
# sGa+vCgtHUQ23eNqerwwcQYDVR0fBGowaDAyoDCgLoYsaHR0cDovL2NybDMuZGln
# aWNlcnQuY29tL3NoYTItYXNzdXJlZC10cy5jcmwwMqAwoC6GLGh0dHA6Ly9jcmw0
# LmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQtdHMuY3JsMIGFBggrBgEFBQcBAQR5
# MHcwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBPBggrBgEF
# BQcwAoZDaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0U0hBMkFz
# c3VyZWRJRFRpbWVzdGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsFAAOCAQEASBzc
# temaI7znGucgDo5nRv1CclF0CiNHo6uS0iXEcFm+FKDlJ4GlTRQVGQd58NEEw4bZ
# O73+RAJmTe1ppA/2uHDPYuj1UUp4eTZ6J7fz51Kfk6ftQ55757TdQSKJ+4eiRgNO
# /PT+t2R3Y18jUmmDgvoaU+2QzI2hF3MN9PNlOXBL85zWenvaDLw9MtAby/Vh/HUI
# AHa8gQ74wOFcz8QRcucbZEnYIpp1FUL1LTI4gdr0YKK6tFL7XOBhJCVPst/JKahz
# Q1HavWPWH1ub9y4bTxMd90oNcX6Xt/Q/hOvB46NJofrOp79Wz7pZdmGJX36ntI5n
# ePk2mOHLKNpbh6aKLzCCBTEwggQZoAMCAQICEAqhJdbWMht+QeQF2jaXwhUwDQYJ
# KoZIhvcNAQELBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQg
# QXNzdXJlZCBJRCBSb290IENBMB4XDTE2MDEwNzEyMDAwMFoXDTMxMDEwNzEyMDAw
# MFowcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UE
# CxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1
# cmVkIElEIFRpbWVzdGFtcGluZyBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAL3QMu5LzY9/3am6gpnFOVQoV7YjSsQOB0UzURB90Pl9TWh+57ag9I2z
# iOSXv2MhkJi/E7xX08PhfgjWahQAOPcuHjvuzKb2Mln+X2U/4Jvr40ZHBhpVfgsn
# fsCi9aDg3iI/Dv9+lfvzo7oiPhisEeTwmQNtO4V8CdPuXciaC1TjqAlxa+DPIhAP
# dc9xck4Krd9AOly3UeGheRTGTSQjMF287DxgaqwvB8z98OpH2YhQXv1mblZhJymJ
# hFHmgudGUP2UKiyn5HU+upgPhH+fMRTWrdXyZMt7HgXQhBlyF/EXBu89zdZN7wZC
# /aJTKk+FHcQdPK/P2qwQ9d2srOlW/5MCAwEAAaOCAc4wggHKMB0GA1UdDgQWBBT0
# tuEgHf4prtLkYaWyoiWyyBc1bjAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd
# 823IDzASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUE
# DDAKBggrBgEFBQcDCDB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0f
# BHoweDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNz
# dXJlZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBQBgNVHSAESTBHMDgGCmCGSAGG
# /WwAAgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQ
# UzALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggEBAHGVEulRh1Zpze/d2nyq
# Y3qzeM8GN0CE70uEv8rPAwL9xafDDiBCLK938ysfDCFaKrcFNB1qrpn4J6Jmvwmq
# YN92pDqTD/iy0dh8GWLoXoIlHsS6HHssIeLWWywUNUMEaLLbdQLgcseY1jxk5R9I
# EBhfiThhTWJGJIdjjJFSLK8pieV4H9YLFKWA1xJHcLN11ZOFk362kmf7U2GJqPVr
# lsD0WGkNfMgBsbkodbeZY4UijGHKeZR+WfyMD+NvtQEmtmyl7odRIeRYYJu6DC0r
# baLEfrvEJStHAgh8Sa4TtuF8QkIoxhhWz0E0tmZdtnR79VYzIi8iNrJLokqV2PWm
# jlIxggJNMIICSQIBATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdp
# Q2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBAhANQkrgvjqI/2BA
# Ic4UAPDdMA0GCWCGSAFlAwQCAQUAoIGYMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAcBgkqhkiG9w0BCQUxDxcNMjEwMjAxMjEzNjU1WjArBgsqhkiG9w0BCRAC
# DDEcMBowGDAWBBTh14Ko4ZG+72vKFpG1qrSUpiSb8zAvBgkqhkiG9w0BCQQxIgQg
# aX9eouCzwG8Y851HNrsYZMkHqjgy8EHrI1fSZowA3WowDQYJKoZIhvcNAQEBBQAE
# ggEAqWto+pxuncPy22Dk8TNg2RGLy6VZqToj7YczQd1Yp8zue5nNN7MhVA8iiaEr
# YWenx/4M30NFsA7bimJcBcmJZP0wew7WAPuu4DHJeJbc0QD0rjHQ7QxDOueFq6A7
# 3zRbwDhOAhbeosEcXvZHBSeH1srPQ/hwrILdLzWbbhSL7N6bSfz3Cf2O1WqJ7jHB
# 3denL7/+Q4yXfsyj3gZIb+IX1RhMRMGB4UTRpIy/SOmBeQr1e8kuLr/W5eFvmjhr
# eKRpqzU1KhSwLMQOmQsNxOAC4W2iMfTlpPKoB+aD+l7S2PqPj0uNT9YhjvLD+2ho
# mnrrJq5wmqN7SvdMYDw2w5Fi7g==
# SIG # End signature block
